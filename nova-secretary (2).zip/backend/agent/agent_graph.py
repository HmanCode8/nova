# 示例：LangGraph 核心 Graph 骨架（v2 自主执行 Agent）
# 关键点：interrupt() 实现删除确认断点；异步 astream 流式输出；多轮循环支持长任务
# 说明：这是给 TRAE 的参考骨架，非完整实现，按此结构扩展

from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, END, START
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import interrupt, Command
from langchain_openai import ChatOpenAI
from langchain_core.messages import BaseMessage

# ==== 状态定义 ====
class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]
    task_id: str          # 后台任务ID
    session_id: str       # 会话ID
    trace_id: str         # 轨迹ID
    pending_delete: bool  # 是否在等待删除确认

# ==== 工具中间件：删除拦截 + Trace 埋点 ====
# 说明：所有工具调用统一经过此中间件，识别 file_delete 触发 interrupt
def tool_middleware(tool_name: str, params: dict, trace_logger):
    """工具调用前置中间件"""
    # 1. 写 Trace 开始日志
    trace_logger.start(tool_name, params)
    # 2. 白名单路径校验（由独立校验器处理，这里示意）
    # 3. 判断是否删除操作
    if tool_name == "file_delete":
        path = params.get("path")
        # 触发人工确认，中断 Graph，等待前端确认
        accepted = interrupt({
            "type": "delete_confirm",
            "tool": "file_delete",
            "path": path,
        })
        if not accepted:
            trace_logger.end(tool_name, status="cancelled")
            return "用户已取消删除操作"
        trace_logger.end(tool_name, status="confirmed")
        return f"已删除: {path}"
    # 非删除工具：放行，由真实工具函数执行
    result = execute_real_tool(tool_name, params)
    trace_logger.end(tool_name, result)
    return result

# ==== 核心 Graph 节点 ====
def agent_node(state: AgentState):
    """思考规划节点：调用 LLM 决定下一步"""
    llm = ChatOpenAI(
        base_url="http://localhost:11434/v1",  # 示例 Ollama；可配 DeepSeek 等
        api_key="ollama",
        model="qwen2.5:7b",
    ).bind_tools(get_all_tools())
    resp = llm.invoke(state["messages"])
    return {"messages": [resp]}

def tool_node(state: AgentState):
    """工具执行节点：统一经中间件拦截"""
    # 取出 LLM 请求的工具调用
    # 对每个 tool_call，走 tool_middleware 拦截
    # 返回 ToolMessage
    return {"messages": [tool_result_message]}

def should_continue(state: AgentState):
    """路由判断：有工具调用继续，否则结束"""
    last = state["messages"][-1]
    if getattr(last, "tool_calls", None):
        return "tools"
    return END

# ==== 构建 Graph ====
def build_graph():
    checkpointer = MemorySaver()  # 保存删除确认中断现场
    builder = StateGraph(AgentState)
    builder.add_node("agent", agent_node)
    builder.add_node("tools", tool_node)
    builder.add_edge(START, "agent")
    builder.add_conditional_edges("agent", should_continue, {"tools": "tools", END: END})
    builder.add_edge("tools", "agent")
    graph = builder.compile(checkpointer=checkpointer)
    return graph

# ==== 工具集合（示意） ====
def get_all_tools():
    # 内置工具：file_read / file_write / file_edit / file_open / file_delete
    #         tavily_search / clipboard_read / shell_run / present
    #         screen_capture / image_ocr / image_vl
    # MCP 工具：由 mcp_manager 动态加载后合并
    return []

def execute_real_tool(tool_name, params):
    """真实工具执行（由各工具模块实现）"""
    return f"{tool_name} executed"
